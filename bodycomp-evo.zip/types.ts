
export interface PhotoRecord {
  id: string;
  date: string; // ISO date
  type: 'front' | 'side' | 'back';
  base64: string;
  notes?: string;
}

export interface CheckIn {
  id: string;
  date: string;
  weight: number;
  bodyFatPercentage?: number;
  muscleMass?: number;
  photos: PhotoRecord[];
  aiAnalysis?: string;
}

export interface ClientProfile {
  id: string;
  name: string;
  goal: string; // 'Salud', 'Estética', 'Rendimiento', etc.
  checkIns: CheckIn[];
}

export interface FileNode {
  name: string;
  type: 'folder' | 'file';
  size?: string;
  modified?: string;
  children?: FileNode[];
  fileType?: 'jpg' | 'json' | 'pdf' | 'png';
}

export enum GeminiModel {
  FLASH = 'gemini-2.5-flash',
  PRO = 'gemini-3-pro-preview',
  IMAGE_GEN = 'gemini-2.5-flash-image',
}

export interface EvolutionStage {
  stageName: string; // e.g., "Fase 1: Adaptación", "Fase 2: Construcción", "Fase 3: Definición"
  monthsFromNow: number;
  predictedWeight: number;
  description: string;
  visualPrompt: string; // The prompt to generate the image
}
