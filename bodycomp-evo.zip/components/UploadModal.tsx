import React, { useState } from 'react';
import { CheckIn, PhotoRecord } from '../types';

interface UploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (checkIn: CheckIn) => void;
}

export const UploadModal: React.FC<UploadModalProps> = ({ isOpen, onClose, onSave }) => {
  const [weight, setWeight] = useState<number>(0);
  const [bodyFat, setBodyFat] = useState<number>(0);
  const [muscleMass, setMuscleMass] = useState<number>(0);
  const [frontImage, setFrontImage] = useState<string | null>(null);
  const [sideImage, setSideImage] = useState<string | null>(null);
  const [date, setDate] = useState<string>(new Date().toISOString().split('T')[0]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, type: 'front' | 'side') => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (type === 'front') setFrontImage(reader.result as string);
        else setSideImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!frontImage) {
      alert("La foto frontal es obligatoria.");
      return;
    }

    const photos: PhotoRecord[] = [
      { id: crypto.randomUUID(), date, type: 'front', base64: frontImage }
    ];
    
    if (sideImage) {
      photos.push({ id: crypto.randomUUID(), date, type: 'side', base64: sideImage });
    }

    const newCheckIn: CheckIn = {
      id: crypto.randomUUID(),
      date,
      weight,
      bodyFatPercentage: bodyFat || undefined,
      muscleMass: muscleMass || undefined,
      photos
    };

    onSave(newCheckIn);
    onClose();
    // Reset form
    setFrontImage(null);
    setSideImage(null);
    setWeight(0);
    setBodyFat(0);
    setMuscleMass(0);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl w-full max-w-lg overflow-hidden flex flex-col max-h-[90vh]">
        <div className="p-4 border-b border-gray-100 flex justify-between items-center bg-gray-50">
          <h2 className="text-xl font-bold text-gray-800">Nuevo Check-In</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <span className="material-icons">close</span>
          </button>
        </div>
        
        <div className="p-6 overflow-y-auto">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Fecha</label>
              <input 
                type="date" 
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full border border-gray-300 rounded-lg p-2 focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">Peso (kg)</label>
                <input 
                  type="number" 
                  step="0.1"
                  value={weight}
                  onChange={(e) => setWeight(parseFloat(e.target.value))}
                  className="w-full border border-gray-300 rounded-lg p-2 focus:ring-2 focus:ring-blue-500 outline-none"
                  required
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">% Grasa</label>
                <input 
                  type="number" 
                  step="0.1"
                  value={bodyFat}
                  onChange={(e) => setBodyFat(parseFloat(e.target.value))}
                  className="w-full border border-gray-300 rounded-lg p-2 focus:ring-2 focus:ring-blue-500 outline-none"
                  placeholder="Opcional"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">Masa Musc. (kg)</label>
                <input 
                  type="number" 
                  step="0.1"
                  value={muscleMass}
                  onChange={(e) => setMuscleMass(parseFloat(e.target.value))}
                  className="w-full border border-gray-300 rounded-lg p-2 focus:ring-2 focus:ring-blue-500 outline-none"
                  placeholder="Opcional"
                />
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Foto Frontal (Requerida)</label>
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center hover:bg-gray-50 transition-colors bg-gray-50">
                  <input type="file" accept="image/*" onChange={(e) => handleFileChange(e, 'front')} className="hidden" id="front-upload" />
                  <label htmlFor="front-upload" className="cursor-pointer flex flex-col items-center">
                    {frontImage ? (
                      <img src={frontImage} alt="Front Preview" className="h-40 object-contain rounded shadow-sm" />
                    ) : (
                      <>
                        <span className="material-icons text-blue-500 text-3xl mb-2">add_a_photo</span>
                        <span className="text-sm text-gray-500">Subir Vista Frontal</span>
                      </>
                    )}
                  </label>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Foto de Perfil (Recomendada)</label>
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center hover:bg-gray-50 transition-colors bg-gray-50">
                  <input type="file" accept="image/*" onChange={(e) => handleFileChange(e, 'side')} className="hidden" id="side-upload" />
                  <label htmlFor="side-upload" className="cursor-pointer flex flex-col items-center">
                    {sideImage ? (
                      <img src={sideImage} alt="Side Preview" className="h-40 object-contain rounded shadow-sm" />
                    ) : (
                      <>
                        <span className="material-icons text-gray-400 text-3xl mb-2">add_photo_alternate</span>
                        <span className="text-sm text-gray-500">Subir Vista Lateral</span>
                      </>
                    )}
                  </label>
                </div>
              </div>
            </div>

            <button type="submit" className="w-full bg-blue-600 text-white py-3 rounded-xl font-bold shadow-md hover:bg-blue-700 transition-all transform active:scale-95">
              Guardar Progreso
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};