import React from 'react';

export const PhotoInstructions: React.FC = () => {
  return (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 mb-6">
      <h3 className="text-xl font-bold text-gray-800 mb-6 flex items-center border-b pb-4">
        <span className="material-icons mr-2 text-blue-600">photo_camera</span>
        Guía de Fotografía
      </h3>
      
      <div className="space-y-6">
        {/* Section 1: Setup */}
        <div>
          <h4 className="font-semibold text-gray-800 mb-3 flex items-center text-sm uppercase tracking-wider">
            <span className="material-icons text-sm mr-2 text-gray-400">tungsten</span>
            Iluminación y Entorno
          </h4>
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-gray-50 p-3 rounded-lg text-sm text-gray-600 flex flex-col items-center text-center">
               <span className="material-icons text-yellow-500 mb-2">light_mode</span>
               <span>Luz natural frente a ti o habitación muy iluminada.</span>
            </div>
            <div className="bg-gray-50 p-3 rounded-lg text-sm text-gray-600 flex flex-col items-center text-center">
               <span className="material-icons text-gray-400 mb-2">wallpaper</span>
               <span>Fondo plano y neutro (pared blanca ideal).</span>
            </div>
            <div className="bg-gray-50 p-3 rounded-lg text-sm text-gray-600 flex flex-col items-center text-center">
               <span className="material-icons text-blue-500 mb-2">checkroom</span>
               <span>Usa la misma ropa (ropa interior o deportiva ajustada).</span>
            </div>
            <div className="bg-gray-50 p-3 rounded-lg text-sm text-gray-600 flex flex-col items-center text-center">
               <span className="material-icons text-red-400 mb-2">height</span>
               <span>Cámara a la altura del pecho.</span>
            </div>
          </div>
        </div>

        {/* Section 2: Poses */}
        <div>
          <h4 className="font-semibold text-gray-800 mb-3 flex items-center text-sm uppercase tracking-wider">
            <span className="material-icons text-sm mr-2 text-gray-400">accessibility_new</span>
            Poses Clave
          </h4>
          <div className="space-y-3">
             <div className="flex items-start gap-3 p-3 border border-blue-100 bg-blue-50 rounded-lg">
                <span className="material-icons text-blue-600">person</span>
                <div>
                   <span className="font-bold text-gray-800 block text-sm">Frontal</span>
                   <p className="text-xs text-gray-600">Brazos relajados a los lados, palmas hacia el cuerpo, pies separados al ancho de los hombros.</p>
                </div>
             </div>
             <div className="flex items-start gap-3 p-3 border border-gray-100 rounded-lg">
                <span className="material-icons text-gray-500">person_outline</span>
                <div>
                   <span className="font-bold text-gray-800 block text-sm">Perfil (Lateral)</span>
                   <p className="text-xs text-gray-600">Gira 90 grados, brazos colgando naturalmente, mira al frente. No escondas el brazo.</p>
                </div>
             </div>
             <div className="flex items-start gap-3 p-3 border border-gray-100 rounded-lg">
                <span className="material-icons text-gray-500">person</span>
                <div>
                   <span className="font-bold text-gray-800 block text-sm">Espalda (Posterior)</span>
                   <p className="text-xs text-gray-600">Similar a la frontal pero de espaldas. Mantén el cabello recogido si es largo.</p>
                </div>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};