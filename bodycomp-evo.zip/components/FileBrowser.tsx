import React from 'react';
import { ClientProfile, FileNode } from '../types';

interface FileBrowserProps {
  client: ClientProfile;
}

export const FileBrowser: React.FC<FileBrowserProps> = ({ client }) => {
  // Construct the virtual file tree based on client data
  const buildTree = (): FileNode => {
    const imagesNode: FileNode = {
      name: 'images',
      type: 'folder',
      children: client.checkIns.flatMap(c => 
        c.photos.map((p, idx) => ({
          name: `${c.date}_${p.type}_${idx}.jpg`,
          type: 'file',
          fileType: 'jpg',
          size: '1.2 MB', // Mock size
          modified: c.date
        }))
      )
    };

    const jsonNode: FileNode = {
      name: 'json',
      type: 'folder',
      children: client.checkIns.map(c => ({
        name: `data_${c.date}.json`,
        type: 'file',
        fileType: 'json',
        size: '2 KB',
        modified: c.date
      }))
    };
    
    const pdfNode: FileNode = {
        name: 'pdf',
        type: 'folder',
        children: [] // Placeholder
    };

    return {
      name: 'clientes',
      type: 'folder',
      children: [
        {
          name: client.name.replace(/\s+/g, '_').toLowerCase(),
          type: 'folder',
          children: [
            imagesNode,
            jsonNode,
            pdfNode
          ]
        }
      ]
    };
  };

  const root = buildTree();
  const [expandedFolders, setExpandedFolders] = React.useState<Set<string>>(new Set(['clientes', client.name.replace(/\s+/g, '_').toLowerCase(), 'images']));

  const toggleFolder = (path: string) => {
    const newSet = new Set(expandedFolders);
    if (newSet.has(path)) newSet.delete(path);
    else newSet.add(path);
    setExpandedFolders(newSet);
  };

  const renderNode = (node: FileNode, path: string = '') => {
    const currentPath = path ? `${path}/${node.name}` : node.name;
    const isExpanded = expandedFolders.has(currentPath);

    return (
      <div key={currentPath} className="ml-4">
        <div 
          className={`flex items-center gap-2 py-1 px-2 rounded cursor-pointer hover:bg-blue-50 transition-colors ${node.type === 'file' ? 'text-gray-600' : 'text-gray-800 font-medium'}`}
          onClick={() => node.type === 'folder' && toggleFolder(currentPath)}
        >
          <span className={`material-icons text-sm ${node.type === 'folder' ? 'text-yellow-500' : 'text-blue-400'}`}>
            {node.type === 'folder' ? (isExpanded ? 'folder_open' : 'folder') : 'description'}
          </span>
          <span className="text-sm truncate font-mono">{node.name}</span>
          {node.type === 'file' && (
            <span className="text-[10px] text-gray-400 ml-auto mr-4">{node.modified}</span>
          )}
        </div>
        {node.type === 'folder' && isExpanded && node.children && (
          <div className="border-l border-gray-200 ml-2">
            {node.children.map(child => renderNode(child, currentPath))}
            {node.children.length === 0 && <div className="text-xs text-gray-400 ml-6 py-1 italic">Vacío</div>}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-0 overflow-hidden">
      <div className="bg-gray-50 border-b border-gray-200 p-3 flex items-center justify-between">
        <div className="flex items-center">
            <span className="material-icons text-gray-500 mr-2">dns</span>
            <h3 className="text-sm font-semibold text-gray-700">Explorador de Archivos</h3>
        </div>
        <span className="text-[10px] bg-green-100 text-green-700 px-2 py-0.5 rounded-full">Firebase</span>
      </div>
      <div className="p-4 max-h-[300px] overflow-y-auto">
        {renderNode(root)}
      </div>
    </div>
  );
};