
import React, { useState } from 'react';
import { analyzeBodyComposition, findLocalResources, generateGoalPhysique, getGeneralFitnessAdvice, predictEvolutionPlan } from '../services/geminiService';
import { ClientProfile, EvolutionStage } from '../types';

interface GeminiToolsProps {
  client: ClientProfile;
}

export const GeminiTools: React.FC<GeminiToolsProps> = ({ client }) => {
  const [activeTab, setActiveTab] = useState<'analyze' | 'resources' | 'visualize' | 'search'>('analyze');
  
  // Analysis State
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<string>('');
  
  // Resources (Maps) State
  const [resourceQuery, setResourceQuery] = useState('Gimnasios de Crossfit cercanos');
  const [resourceResult, setResourceResult] = useState<{text: string, grounding?: any} | null>(null);
  const [isLoadingResources, setIsLoadingResources] = useState(false);

  // Search State
  const [searchQuery, setSearchQuery] = useState('Mejor dieta para ganar músculo magro');
  const [searchResult, setSearchResult] = useState<{text: string, chunks?: any} | null>(null);
  const [isSearching, setIsSearching] = useState(false);

  // Visualize (Image Gen) State
  const [visualizeMode, setVisualizeMode] = useState<'prompt' | 'evolution'>('prompt');
  
  // Manual Prompt State
  const [genPrompt, setGenPrompt] = useState('Físico masculino ideal, musculoso y definido, en la playa');
  const [genImages, setGenImages] = useState<string[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);

  // Evolution Prediction State
  const [evolutionPlan, setEvolutionPlan] = useState<EvolutionStage[]>([]);
  const [isPredicting, setIsPredicting] = useState(false);
  const [evolutionImages, setEvolutionImages] = useState<{[key: number]: string}>({}); // Map stage index to image url
  const [isGeneratingEvoImage, setIsGeneratingEvoImage] = useState<number | null>(null);

  const handleAnalysis = async () => {
    if (client.checkIns.length === 0) return;
    setIsAnalyzing(true);
    const latest = client.checkIns[client.checkIns.length - 1];
    const frontPhoto = latest.photos.find(p => p.type === 'front');
    const sidePhoto = latest.photos.find(p => p.type === 'side');
    
    // Find previous checkin for comparison if available
    const prev = client.checkIns.length > 1 ? client.checkIns[client.checkIns.length - 2] : undefined;
    const prevFront = prev?.photos.find(p => p.type === 'front');

    if (frontPhoto) {
      const result = await analyzeBodyComposition(
        frontPhoto.base64,
        sidePhoto?.base64 || '',
        client.goal,
        prevFront?.base64
      );
      setAnalysisResult(result);
    }
    setIsAnalyzing(false);
  };

  const handleFindResources = async () => {
    setIsLoadingResources(true);
    try {
      // Get location
      navigator.geolocation.getCurrentPosition(async (pos) => {
        const result = await findLocalResources(resourceQuery, { 
          lat: pos.coords.latitude, 
          lng: pos.coords.longitude 
        });
        setResourceResult(result);
        setIsLoadingResources(false);
      }, () => {
        // Fallback without precise location
        findLocalResources(resourceQuery).then(res => {
          setResourceResult(res);
          setIsLoadingResources(false);
        });
      });
    } catch (e) {
      console.error(e);
      setIsLoadingResources(false);
    }
  };

  const handleSearch = async () => {
    setIsSearching(true);
    try {
      const res = await getGeneralFitnessAdvice(searchQuery);
      setSearchResult(res);
    } catch(e) {
      console.error(e);
    } finally {
      setIsSearching(false);
    }
  };

  const handleGenerateManual = async () => {
    setIsGenerating(true);
    try {
      const images = await generateGoalPhysique(genPrompt);
      setGenImages(images);
    } catch (error: any) {
       console.error(error);
       alert("Error generando imagen. Intente de nuevo.");
    } finally {
      setIsGenerating(false);
    }
  };

  const handlePredictEvolution = async () => {
    if (client.checkIns.length === 0) {
        alert("Necesitas al menos un Check-In para predecir tu evolución.");
        return;
    }
    setIsPredicting(true);
    setEvolutionImages({});
    try {
        const latest = client.checkIns[client.checkIns.length - 1];
        const plan = await predictEvolutionPlan(latest.weight, latest.bodyFatPercentage, client.goal);
        setEvolutionPlan(plan);
    } catch (e) {
        console.error(e);
    } finally {
        setIsPredicting(false);
    }
  };

  const handleGenerateEvolutionImage = async (stage: EvolutionStage, index: number) => {
    const latest = client.checkIns[client.checkIns.length - 1];
    const frontPhoto = latest.photos.find(p => p.type === 'front');
    
    if (!frontPhoto) {
        alert("No se encontró foto frontal en el último check-in.");
        return;
    }

    setIsGeneratingEvoImage(index);
    try {
        const images = await generateGoalPhysique(stage.visualPrompt, frontPhoto.base64);
        if (images.length > 0) {
            setEvolutionImages(prev => ({...prev, [index]: images[0]}));
        }
    } catch (e) {
        console.error(e);
        alert("Error generando visualización.");
    } finally {
        setIsGeneratingEvoImage(null);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 mt-6 overflow-hidden">
      <div className="flex border-b border-gray-200 bg-gray-50">
        <button 
          onClick={() => setActiveTab('analyze')}
          className={`flex-1 py-4 text-sm font-semibold flex items-center justify-center gap-2 transition-colors ${activeTab === 'analyze' ? 'bg-white text-blue-600 border-t-2 border-blue-600' : 'text-gray-500 hover:text-gray-700'}`}
        >
          <span className="material-icons text-lg">analytics</span> Análisis
        </button>
        <button 
          onClick={() => setActiveTab('search')}
          className={`flex-1 py-4 text-sm font-semibold flex items-center justify-center gap-2 transition-colors ${activeTab === 'search' ? 'bg-white text-blue-600 border-t-2 border-blue-600' : 'text-gray-500 hover:text-gray-700'}`}
        >
          <span className="material-icons text-lg">search</span> Consejos
        </button>
        <button 
          onClick={() => setActiveTab('resources')}
          className={`flex-1 py-4 text-sm font-semibold flex items-center justify-center gap-2 transition-colors ${activeTab === 'resources' ? 'bg-white text-blue-600 border-t-2 border-blue-600' : 'text-gray-500 hover:text-gray-700'}`}
        >
          <span className="material-icons text-lg">place</span> Lugares
        </button>
        <button 
          onClick={() => setActiveTab('visualize')}
          className={`flex-1 py-4 text-sm font-semibold flex items-center justify-center gap-2 transition-colors ${activeTab === 'visualize' ? 'bg-white text-blue-600 border-t-2 border-blue-600' : 'text-gray-500 hover:text-gray-700'}`}
        >
          <span className="material-icons text-lg">auto_awesome</span> Meta
        </button>
      </div>

      <div className="p-6 min-h-[300px]">
        {/* ANALYSIS TAB */}
        {activeTab === 'analyze' && (
          <div>
            <div className="flex justify-between items-center mb-4">
               <h3 className="font-bold text-gray-800">Análisis de Composición con Gemini</h3>
               <button 
                onClick={handleAnalysis}
                disabled={isAnalyzing || client.checkIns.length === 0}
                className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 disabled:opacity-50 transition-colors shadow-sm"
               >
                 {isAnalyzing ? <span className="animate-spin material-icons">refresh</span> : <span className="material-icons">sparkles</span>}
                 Analizar Progreso
               </button>
            </div>
            
            {client.checkIns.length === 0 ? (
               <div className="text-center py-10 bg-gray-50 rounded-xl border border-dashed border-gray-300">
                  <span className="material-icons text-gray-400 text-4xl mb-2">add_a_photo</span>
                  <p className="text-gray-500 italic">Sube fotos para comenzar el análisis.</p>
               </div>
            ) : (
                <div className="prose max-w-none text-gray-700 bg-indigo-50 p-6 rounded-xl border border-indigo-100 shadow-inner">
                  {analysisResult ? (
                    <div dangerouslySetInnerHTML={{ __html: analysisResult.replace(/\n/g, '<br />').replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>') }} />
                  ) : (
                    <div className="text-center py-6">
                         <p className="text-indigo-800 font-medium">Haz clic en Analizar para obtener insights de tus últimas fotos.</p>
                         <p className="text-indigo-400 text-sm mt-1">Compararemos tu estado actual con tu objetivo de "{client.goal}".</p>
                    </div>
                  )}
                </div>
            )}
            <p className="text-xs text-gray-400 mt-2 text-center">* No es consejo médico. Solo para propósitos de seguimiento y fitness.</p>
          </div>
        )}

        {/* SEARCH TAB */}
        {activeTab === 'search' && (
            <div>
                 <h3 className="font-bold text-gray-800 mb-4">Búsqueda Inteligente de Fitness</h3>
                 <div className="flex gap-2 mb-4">
                     <input 
                       type="text" 
                       value={searchQuery}
                       onChange={(e) => setSearchQuery(e.target.value)}
                       className="flex-1 border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-blue-500 outline-none"
                       placeholder="Pregunta sobre dieta, entrenamiento..."
                     />
                     <button 
                       onClick={handleSearch}
                       disabled={isSearching}
                       className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors shadow-sm"
                     >
                        {isSearching ? '...' : 'Buscar'}
                     </button>
                 </div>
                 {searchResult && (
                     <div className="bg-gray-50 p-5 rounded-xl border border-gray-200 shadow-sm">
                         <div className="prose text-sm text-gray-800 whitespace-pre-line">
                             {searchResult.text}
                         </div>
                         {searchResult.chunks && (
                            <div className="mt-4 pt-4 border-t border-gray-200">
                                <h4 className="text-xs font-bold text-gray-500 uppercase mb-2">Fuentes</h4>
                                <div className="flex flex-wrap gap-2">
                                    {searchResult.chunks.map((chunk: any, i: number) => 
                                        chunk.web?.uri ? (
                                            <a key={i} href={chunk.web.uri} target="_blank" rel="noreferrer" className="text-xs bg-white border border-gray-300 px-3 py-1 rounded-full hover:bg-blue-50 text-blue-600 truncate max-w-[200px] block transition-colors">
                                                {chunk.web.title || chunk.web.uri}
                                            </a>
                                        ) : null
                                    )}
                                </div>
                            </div>
                         )}
                     </div>
                 )}
            </div>
        )}

        {/* MAPS TAB */}
        {activeTab === 'resources' && (
          <div>
            <h3 className="font-bold text-gray-800 mb-4">Encontrar Profesionales Locales</h3>
            <div className="flex gap-2 mb-4">
              <input 
                type="text"
                value={resourceQuery}
                onChange={(e) => setResourceQuery(e.target.value)}
                className="flex-1 border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-green-500 outline-none"
                placeholder="ej. Nutricionista, Gimnasio, Fisio"
              />
              <button 
                onClick={handleFindResources}
                disabled={isLoadingResources}
                className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition-colors shadow-sm"
              >
                {isLoadingResources ? 'Buscando...' : 'Buscar'}
              </button>
            </div>
            
            {resourceResult && (
              <div className="bg-gray-50 p-4 rounded-xl border border-gray-200">
                <p className="whitespace-pre-wrap text-sm text-gray-700 mb-4">{resourceResult.text}</p>
                {resourceResult.grounding?.map((chunk: any, i: number) => {
                    const place = chunk.maps;
                    if (!place) return null;
                    return (
                        <div key={i} className="bg-white p-3 rounded-lg border border-gray-200 mb-2 shadow-sm hover:shadow-md transition-shadow">
                            <h5 className="font-bold text-gray-800 flex items-center">
                                <span className="material-icons text-red-500 text-sm mr-1">location_on</span>
                                {place.title}
                            </h5>
                             {place.placeId && (
                                <a 
                                    href={`https://www.google.com/maps/place/?q=place_id:${place.placeId}`}
                                    target="_blank"
                                    rel="noreferrer" 
                                    className="text-blue-600 text-xs mt-1 inline-block hover:underline"
                                >
                                    Ver en Google Maps
                                </a>
                             )}
                        </div>
                    )
                })}
              </div>
            )}
          </div>
        )}

        {/* VISUALIZE TAB */}
        {activeTab === 'visualize' && (
          <div>
             <div className="flex gap-4 mb-6">
                 <button 
                    onClick={() => setVisualizeMode('prompt')}
                    className={`px-4 py-2 rounded-lg text-sm font-bold transition-all ${visualizeMode === 'prompt' ? 'bg-purple-100 text-purple-700 ring-2 ring-purple-500' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
                 >
                     Manual
                 </button>
                 <button 
                    onClick={() => setVisualizeMode('evolution')}
                    className={`px-4 py-2 rounded-lg text-sm font-bold transition-all ${visualizeMode === 'evolution' ? 'bg-purple-100 text-purple-700 ring-2 ring-purple-500' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
                 >
                     Proyección de Evolución
                 </button>
             </div>

             {visualizeMode === 'prompt' ? (
                 <>
                    <h3 className="font-bold text-gray-800 mb-2">Visualización de Meta (Libre)</h3>
                    <div className="mb-4">
                        <textarea 
                            value={genPrompt}
                            onChange={(e) => setGenPrompt(e.target.value)}
                            className="w-full border border-gray-300 rounded-lg p-3 text-sm focus:ring-2 focus:ring-purple-500 outline-none"
                            rows={3}
                            placeholder="Describe tu físico ideal..."
                        />
                    </div>
                    <button 
                        onClick={handleGenerateManual}
                        disabled={isGenerating}
                        className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 text-white py-3 rounded-lg font-bold shadow hover:opacity-90 transition-opacity flex justify-center items-center gap-2"
                    >
                        {isGenerating ? <span className="animate-spin material-icons">refresh</span> : <span className="material-icons">palette</span>}
                        Generar Imagen
                    </button>
                    {genImages.length > 0 && (
                        <div className="mt-6 grid grid-cols-1 gap-4">
                            {genImages.map((img, idx) => (
                                <div key={idx} className="relative rounded-xl overflow-hidden shadow-lg group">
                                    <img src={img} alt="Generated Goal" className="w-full h-auto" />
                                    <a href={img} download={`meta-${idx}.png`} className="absolute top-2 right-2 bg-white p-2 rounded-full shadow hover:bg-gray-100 opacity-0 group-hover:opacity-100 transition-opacity">
                                        <span className="material-icons text-gray-700">download</span>
                                    </a>
                                </div>
                            ))}
                        </div>
                    )}
                 </>
             ) : (
                 <>
                    <h3 className="font-bold text-gray-800 mb-2">Tu Camino al Éxito</h3>
                    <p className="text-sm text-gray-500 mb-4">
                        Basado en tus datos actuales y el objetivo "{client.goal}", Gemini proyectará 3 hitos clave.
                        Luego podrás visualizar tu físico en cada etapa usando tu última foto.
                    </p>
                    
                    {evolutionPlan.length === 0 && (
                        <button 
                            onClick={handlePredictEvolution}
                            disabled={isPredicting || client.checkIns.length === 0}
                            className="w-full bg-indigo-600 text-white py-4 rounded-xl font-bold shadow-md hover:bg-indigo-700 transition-all flex justify-center items-center gap-2"
                        >
                            {isPredicting ? <span className="animate-spin material-icons">refresh</span> : <span className="material-icons">timeline</span>}
                            Calcular Plan de Evolución
                        </button>
                    )}

                    {evolutionPlan.length > 0 && (
                        <div className="space-y-8 mt-6 relative">
                            {/* Vertical Line */}
                            <div className="absolute left-4 top-4 bottom-4 w-0.5 bg-gray-200 z-0"></div>

                            {evolutionPlan.map((stage, idx) => (
                                <div key={idx} className="relative z-10 pl-10">
                                    {/* Timeline Dot */}
                                    <div className="absolute left-1 top-1 w-6 h-6 rounded-full bg-indigo-600 text-white text-[10px] flex items-center justify-center font-bold border-4 border-white shadow-sm">
                                        {idx + 1}
                                    </div>

                                    <div className="bg-gray-50 p-4 rounded-xl border border-gray-200 hover:border-indigo-200 transition-colors">
                                        <div className="flex justify-between items-start mb-2">
                                            <div>
                                                <h4 className="font-bold text-gray-900">{stage.stageName}</h4>
                                                <span className="text-xs font-semibold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full uppercase tracking-wider">
                                                    +{stage.monthsFromNow} Meses
                                                </span>
                                            </div>
                                            <div className="text-right">
                                                <div className="text-xl font-bold text-gray-800">{stage.predictedWeight}kg</div>
                                                <div className="text-[10px] text-gray-500 uppercase">Peso Estimado</div>
                                            </div>
                                        </div>
                                        
                                        <p className="text-sm text-gray-600 mb-4 leading-relaxed">
                                            {stage.description}
                                        </p>

                                        {evolutionImages[idx] ? (
                                            <div className="relative rounded-lg overflow-hidden shadow-sm border border-gray-100 group">
                                                <img src={evolutionImages[idx]} alt={stage.stageName} className="w-full h-auto" />
                                                <div className="absolute bottom-0 left-0 right-0 bg-black bg-opacity-60 text-white text-xs p-2 backdrop-blur-sm">
                                                    Proyección Generada por IA
                                                </div>
                                            </div>
                                        ) : (
                                            <button 
                                                onClick={() => handleGenerateEvolutionImage(stage, idx)}
                                                disabled={isGeneratingEvoImage === idx}
                                                className="w-full bg-white border border-indigo-200 text-indigo-600 py-2 rounded-lg text-sm font-semibold hover:bg-indigo-50 transition-colors flex justify-center items-center gap-2"
                                            >
                                                {isGeneratingEvoImage === idx ? (
                                                    <span className="animate-spin material-icons text-sm">refresh</span>
                                                ) : (
                                                    <span className="material-icons text-sm">visibility</span>
                                                )}
                                                Visualizar esta Etapa
                                            </button>
                                        )}
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                 </>
             )}
          </div>
        )}
      </div>
    </div>
  );
};
