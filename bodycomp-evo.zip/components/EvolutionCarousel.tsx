import React, { useState } from 'react';
import { CheckIn } from '../types';

interface EvolutionCarouselProps {
  checkIns: CheckIn[];
}

export const EvolutionCarousel: React.FC<EvolutionCarouselProps> = ({ checkIns }) => {
  // Sort checkins by date ascending
  const sortedCheckIns = [...checkIns].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  const [startIndex, setStartIndex] = useState(0);

  if (sortedCheckIns.length === 0) {
    return <div className="p-8 text-center text-gray-500 italic border border-dashed border-gray-300 rounded-xl">No hay fotos subidas aún. Comienza tu registro.</div>;
  }

  const handleNext = () => {
    if (startIndex < sortedCheckIns.length - 1) {
      setStartIndex(prev => prev + 1);
    }
  };

  const handlePrev = () => {
    if (startIndex > 0) {
      setStartIndex(prev => prev - 1);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-xl font-bold text-gray-800 flex items-center">
          <span className="material-icons mr-2 text-indigo-500">history_edu</span>
          Evolución Corporal
        </h3>
        <div className="flex gap-2">
          <button 
            onClick={handlePrev} 
            disabled={startIndex === 0}
            className="p-2 rounded-full hover:bg-gray-100 disabled:opacity-30 border border-gray-200"
          >
            <span className="material-icons">chevron_left</span>
          </button>
          <button 
            onClick={handleNext} 
            disabled={startIndex >= sortedCheckIns.length - 1} 
            className="p-2 rounded-full hover:bg-gray-100 disabled:opacity-30 border border-gray-200"
          >
            <span className="material-icons">chevron_right</span>
          </button>
        </div>
      </div>

      <div className="overflow-x-auto flex gap-6 pb-4 scrollbar-hide">
        {sortedCheckIns.map((checkIn, index) => {
           const front = checkIn.photos.find(p => p.type === 'front');
           const side = checkIn.photos.find(p => p.type === 'side');
           
           return (
             <div key={checkIn.id} className="min-w-[280px] bg-white rounded-xl p-4 border border-gray-200 shadow-sm">
                <div className="mb-3 flex justify-between items-center border-b border-gray-100 pb-2">
                   <span className="font-bold text-gray-800">{new Date(checkIn.date).toLocaleDateString('es-ES')}</span>
                </div>
                
                {/* Metrics Grid */}
                <div className="grid grid-cols-3 gap-2 mb-3 text-center">
                    <div className="bg-blue-50 rounded p-1">
                        <div className="text-[10px] text-blue-500 font-bold uppercase">Peso</div>
                        <div className="text-sm font-semibold text-gray-800">{checkIn.weight}kg</div>
                    </div>
                    <div className="bg-orange-50 rounded p-1">
                        <div className="text-[10px] text-orange-500 font-bold uppercase">% Grasa</div>
                        <div className="text-sm font-semibold text-gray-800">{checkIn.bodyFatPercentage ? `${checkIn.bodyFatPercentage}%` : '-'}</div>
                    </div>
                    <div className="bg-red-50 rounded p-1">
                        <div className="text-[10px] text-red-500 font-bold uppercase">Músculo</div>
                        <div className="text-sm font-semibold text-gray-800">{checkIn.muscleMass ? `${checkIn.muscleMass}kg` : '-'}</div>
                    </div>
                </div>

                <div className="space-y-2">
                  {front && (
                    <div className="aspect-[3/4] bg-gray-100 rounded-lg overflow-hidden relative group border border-gray-100">
                        <img src={front.base64} alt="Frontal" className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
                        <div className="absolute bottom-2 left-2 bg-black bg-opacity-60 text-white text-[10px] px-2 py-1 rounded backdrop-blur-sm">Frontal</div>
                    </div>
                  )}
                  {side && (
                    <div className="aspect-[3/4] bg-gray-100 rounded-lg overflow-hidden relative group border border-gray-100">
                        <img src={side.base64} alt="Lateral" className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
                        <div className="absolute bottom-2 left-2 bg-black bg-opacity-60 text-white text-[10px] px-2 py-1 rounded backdrop-blur-sm">Perfil</div>
                    </div>
                  )}
                </div>
             </div>
           );
        })}
      </div>
    </div>
  );
};