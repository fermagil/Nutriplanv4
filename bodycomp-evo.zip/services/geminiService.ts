
import { GoogleGenAI, Type } from "@google/genai";
import { GeminiModel, EvolutionStage } from '../types';

const getAiClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) throw new Error("API_KEY not found in environment");
  return new GoogleGenAI({ apiKey });
};

export const analyzeBodyComposition = async (
  frontPhotoBase64: string,
  sidePhotoBase64: string,
  goal: string,
  prevCheckInFront?: string
): Promise<string> => {
  const ai = getAiClient();
  
  const parts: any[] = [];
  
  // Current Front
  parts.push({
    inlineData: {
      mimeType: 'image/jpeg',
      data: frontPhotoBase64.split(',')[1] || frontPhotoBase64
    }
  });

  // Current Side
  if (sidePhotoBase64) {
    parts.push({
      inlineData: {
        mimeType: 'image/jpeg',
        data: sidePhotoBase64.split(',')[1] || sidePhotoBase64
      }
    });
  }

  // Comparison logic
  let prompt = `Actúa como un entrenador profesional de fitness y experto en composición corporal. 
  El objetivo principal del usuario es: ${goal} (ej. Salud, Estética, Alto Rendimiento).
  Analiza el físico en las imágenes proporcionadas (Frontal y opcionalmente Perfil).
  Identifica grupos musculares clave, postura y estimaciones generales de composición corporal visualmente.
  
  IMPORTANTE:
  1. Sé respetuoso, objetivo y constructivo. 
  2. No des consejos médicos ni diagnósticos.
  3. Enfócate en la simetría, equilibrio y definición muscular.
  4. Proporciona observaciones posturales.
  5. Sugiere áreas de enfoque para el entrenamiento basado en el objetivo "${goal}".
  
  RESPONDE EN ESPAÑOL, usando formato Markdown claro.`;

  if (prevCheckInFront) {
    parts.push({
      inlineData: {
        mimeType: 'image/jpeg',
        data: prevCheckInFront.split(',')[1] || prevCheckInFront
      }
    });
    prompt += `\n\nCompara las primeras imágenes (Actuales) con la última imagen proporcionada (Anterior). Destaca los cambios visibles en la composición corporal (pérdida de grasa, ganancia muscular, etc.).`;
  }

  parts.push({ text: prompt });

  try {
    const response = await ai.models.generateContent({
      model: GeminiModel.PRO, // Using Pro for complex reasoning/vision
      contents: { parts },
      config: {
        systemInstruction: "Eres un consultor experto en fitness. Tu salida debe ser en español y usar markdown.",
      }
    });
    return response.text || "El análisis falló.";
  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    return "Error generando el análisis. Por favor intenta de nuevo.";
  }
};

export const findLocalResources = async (query: string, userLocation?: { lat: number, lng: number }) => {
  const ai = getAiClient();
  
  const config: any = {
    tools: [{ googleMaps: {} }],
  };

  if (userLocation) {
    config.toolConfig = {
      retrievalConfig: {
        latLng: {
          latitude: userLocation.lat,
          longitude: userLocation.lng
        }
      }
    };
  }

  try {
    const response = await ai.models.generateContent({
      model: GeminiModel.FLASH,
      contents: `Encuentra los mejores lugares para: ${query}. Proporciona una lista con calificaciones y dirección. Responde en Español.`,
      config
    });

    const text = response.text;
    const grounding = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
    
    return { text, grounding };
  } catch (error) {
    console.error("Maps Error:", error);
    throw error;
  }
};

export const getGeneralFitnessAdvice = async (query: string) => {
  const ai = getAiClient();
  try {
    const response = await ai.models.generateContent({
      model: GeminiModel.FLASH,
      contents: `Responde esta pregunta de fitness usando Google Search para obtener los últimos estudios/tendencias: ${query}. Responde en Español.`,
      config: {
        tools: [{ googleSearch: {} }]
      }
    });
    return {
      text: response.text,
      chunks: response.candidates?.[0]?.groundingMetadata?.groundingChunks
    };
  } catch (error) {
    console.error("Search Error:", error);
    throw error;
  }
};

export const predictEvolutionPlan = async (
  currentWeight: number,
  currentBodyFat: number | undefined,
  goal: string
): Promise<EvolutionStage[]> => {
  const ai = getAiClient();
  
  const prompt = `
    Como experto en fitness, crea una proyección de 3 hitos para un cliente que sigue un plan riguroso de dieta y ejercicio.
    Datos actuales: Peso ${currentWeight}kg, Grasa ${currentBodyFat || 'No especificada'}%, Objetivo: ${goal}.
    Calcula el peso ideal estimado para ese objetivo y divide el camino en 3 momentos (ej. 3 meses, 6 meses, 12 meses o lo que sea realista).
    
    Devuelve un JSON con esta estructura exacta:
    [
      {
        "stageName": "Nombre de la fase (ej. Base, Construcción, Definición)",
        "monthsFromNow": numero_de_meses,
        "predictedWeight": peso_estimado_en_kg_numero,
        "description": "Breve descripción del cambio físico y enfoque (dieta/ejercicio)",
        "visualPrompt": "Una descripción muy detallada en Inglés para generar una imagen del físico de esta persona en esta etapa. Debe describir cambios visibles en musculatura y grasa."
      },
      ... (3 objetos en total)
    ]
  `;

  try {
    const response = await ai.models.generateContent({
      model: GeminiModel.FLASH,
      contents: prompt,
      config: {
        responseMimeType: 'application/json'
      }
    });
    
    const text = response.text;
    if (!text) return [];
    return JSON.parse(text) as EvolutionStage[];
  } catch (error) {
    console.error("Prediction Error:", error);
    return [];
  }
};

export const generateGoalPhysique = async (
  prompt: string, 
  referenceImageBase64?: string
) => {
  const ai = getAiClient();
  
  const parts: any[] = [];
  
  // If we have a reference image, we add it first (Image-to-Image / Editing)
  if (referenceImageBase64) {
    parts.push({
      inlineData: {
        mimeType: 'image/jpeg',
        data: referenceImageBase64.split(',')[1] || referenceImageBase64
      }
    });
    // Adjust prompt to instruct modification
    parts.push({ text: `Modify this person's physique based on this description: ${prompt}. Keep the face and background similar if possible, focus on body composition changes.` });
  } else {
    // Text-to-Image
    parts.push({ text: `A realistic fitness photo. ${prompt}` });
  }

  try {
    const response = await ai.models.generateContent({
      model: GeminiModel.IMAGE_GEN,
      contents: { parts },
      config: {
        imageConfig: {
          aspectRatio: '3:4' // Portrait for body photos
        }
      }
    });

    const images: string[] = [];
    if (response.candidates?.[0]?.content?.parts) {
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          images.push(`data:image/png;base64,${part.inlineData.data}`);
        }
      }
    }
    return images;
  } catch (error) {
    console.error("Image Gen Error:", error);
    throw error;
  }
};
