import React, { useState, useEffect } from 'react';
import { ClientProfile, CheckIn } from './types';
import { EvolutionCarousel } from './components/EvolutionCarousel';
import { UploadModal } from './components/UploadModal';
import { PhotoInstructions } from './components/PhotoInstructions';
import { FileBrowser } from './components/FileBrowser';
import { GeminiTools } from './components/GeminiTools';

const App: React.FC = () => {
  // Mock initial state using LocalStorage or Default
  const [client, setClient] = useState<ClientProfile>(() => {
    const saved = localStorage.getItem('bodyCompClient');
    return saved ? JSON.parse(saved) : {
      id: 'c1',
      name: 'Usuario Uno',
      goal: 'Estética',
      checkIns: []
    };
  });

  const [isUploadOpen, setIsUploadOpen] = useState(false);

  useEffect(() => {
    localStorage.setItem('bodyCompClient', JSON.stringify(client));
  }, [client]);

  const handleSaveCheckIn = (checkIn: CheckIn) => {
    setClient(prev => ({
      ...prev,
      checkIns: [...prev.checkIns, checkIn]
    }));
  };

  const handleGoalChange = (newGoal: string) => {
    setClient(prev => ({ ...prev, goal: newGoal }));
  };

  return (
    <div className="min-h-screen bg-gray-50 pb-12 font-sans">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-40 shadow-sm">
        <div className="max-w-6xl mx-auto px-4 py-3 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-xl flex items-center justify-center text-white font-bold text-xl shadow-md">
              <span className="material-icons text-white">fitness_center</span>
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900 leading-none tracking-tight">BodyComp Evo</h1>
              <p className="text-xs text-gray-500 font-medium">Rastrea. Analiza. Evoluciona.</p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="hidden md:flex flex-col items-end">
              <div className="text-sm font-semibold text-gray-800">{client.name}</div>
              <select 
                value={client.goal}
                onChange={(e) => handleGoalChange(e.target.value)}
                className="text-xs text-gray-500 uppercase tracking-wide border-none bg-transparent p-0 focus:ring-0 text-right cursor-pointer hover:text-blue-600"
              >
                <option value="Salud">Salud (Pérdida/Bienestar)</option>
                <option value="Estética">Estética (Hipertrofia)</option>
                <option value="Rendimiento">Alto Rendimiento</option>
              </select>
            </div>
            <button 
              onClick={() => setIsUploadOpen(true)}
              className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-full font-medium shadow-md flex items-center gap-2 transition-all transform hover:scale-105"
            >
              <span className="material-icons">add_a_photo</span>
              <span className="hidden sm:inline">Nuevo Check-In</span>
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-8 grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left Column: Instructions & File System */}
        <div className="lg:col-span-1 space-y-6">
          
          <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
             <h3 className="font-bold text-gray-800 mb-3 flex items-center">
                <span className="material-icons mr-2 text-blue-500">query_stats</span>
                Resumen de Estadísticas
             </h3>
             <div className="grid grid-cols-2 gap-4 text-center">
                <div className="bg-blue-50 p-3 rounded-xl border border-blue-100">
                   <div className="text-[10px] text-blue-600 uppercase font-bold tracking-wider">Inicio</div>
                   <div className="text-xl font-extrabold text-gray-800">
                      {client.checkIns.length > 0 ? client.checkIns[0].weight : '--'} <span className="text-sm font-normal text-gray-500">kg</span>
                   </div>
                </div>
                <div className="bg-green-50 p-3 rounded-xl border border-green-100">
                   <div className="text-[10px] text-green-600 uppercase font-bold tracking-wider">Actual</div>
                   <div className="text-xl font-extrabold text-gray-800">
                      {client.checkIns.length > 0 ? client.checkIns[client.checkIns.length-1].weight : '--'} <span className="text-sm font-normal text-gray-500">kg</span>
                   </div>
                </div>
             </div>
          </div>

          <PhotoInstructions />
          <FileBrowser client={client} />
          
        </div>

        {/* Right Column: Content & Tools */}
        <div className="lg:col-span-2 space-y-6">
          <EvolutionCarousel checkIns={client.checkIns} />
          <GeminiTools client={client} />
        </div>

      </main>

      <UploadModal 
        isOpen={isUploadOpen} 
        onClose={() => setIsUploadOpen(false)} 
        onSave={handleSaveCheckIn} 
      />
    </div>
  );
};

export default App;